package com.shop.polygraf.repositories;

import com.shop.polygraf.entities.SizeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SizeRepository extends JpaRepository<SizeEntity, Integer> {
}

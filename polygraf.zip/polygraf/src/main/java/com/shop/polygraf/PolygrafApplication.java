package com.shop.polygraf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolygrafApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolygrafApplication.class, args);
	}

}

package com.shop.polygraf.repositories;

import com.shop.polygraf.entities.AmountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AmountRepository extends JpaRepository<AmountEntity,Integer> {
}
